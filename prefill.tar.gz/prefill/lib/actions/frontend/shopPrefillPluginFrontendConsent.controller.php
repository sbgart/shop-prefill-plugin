<?php

/**
 * Контроллер управления согласием и историей предзаполнения
 *
 * Действия:
 * - grant       — дать согласие на сохранение данных
 * - revoke      — отозвать согласие и удалить guest_hash (чтобы следующий за ПК не видел старые данные)
 * - clear       — очистить историю (удалить guest_hash)
 * - clear_form  — очистить сессию формы оформления заказа (checkout + snapshot)
 */
class shopPrefillPluginFrontendConsentController extends waJsonController
{
    /**
     * @throws waException
     */
    public function execute()
    {
        $action = waRequest::post('action', 'grant', waRequest::TYPE_STRING);

        $plugin = shopPrefillPlugin::getInstance();

        try {
            switch ($action) {
                case 'grant':
                    $plugin->getConsentStorage()->grantConsent();
                    shopPrefillPluginLog::info('User granted prefill consent');
                    $this->response = ['status' => 'ok', 'message' => _wp('message.consent.granted')];
                    break;

                case 'revoke':
                    $plugin->getConsentStorage()->revokeConsent();
                    $plugin->getGuestHashStorage()->clearGuestHash();
                    shopPrefillPluginLog::info('User revoked prefill consent');
                    $this->response = ['status' => 'ok', 'message' => _wp('message.consent.revoked')];
                    break;

                case 'clear_form':
                    wa()->getStorage()->remove('shop/checkout');
                    wa()->getStorage()->remove('shop/prefill_snapshot');
                    shopPrefillPluginLog::info('User cleared checkout form session');
                    $this->response = ['status' => 'ok', 'message' => _wp('message.form_data_cleared')];
                    break;

                case 'clear':
                    $plugin->getGuestHashStorage()->clearGuestHash();
                    shopPrefillPluginLog::info('User cleared guest hash history');
                    $this->response = ['status' => 'ok', 'message' => _wp('message.history_cleared')];
                    break;

                default:
                    shopPrefillPluginLog::warning('Unknown action received in consent controller', ['action' => $action]);
                    $this->errors[] = _wp('error.unknown_action');
            }
        } catch (Exception $e) {
            shopPrefillPluginLog::error('Error processing consent action', [
                'action' => $action,
                'message' => $e->getMessage()
            ]);
            $this->errors[] = _wp('error.internal');
        }
    }
}
